#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2011 ~ 2012 Deepin, Inc.
#               2011 ~ 2012 Wang Yong
# 
# Author:     Wang Yong <lazycat.manatee@gmail.com>
# Maintainer: Wang Yong <lazycat.manatee@gmail.com>
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from dtk.ui.draw import draw_text
from dtk.ui.draw import draw_pixbuf
import gtk
import os

'''        
Toolbar 可以添加 button, image, 弹出式菜单, None, 
'''
class Toolbar(gtk.HBox):
    def __init__(self):
        gtk.HBox.__init__(self)
        self.scale_width = 20
        self.scale_height = 20
        
if __name__ == "__main__":
    win = gtk.Window()
    win.connect("destroy", lambda w : gtk.main_quit())
    toolbar = Toolbar()
    win.add(toolbar)
    win.show_all()
    gtk.main()
