rm ./src/*.pyc
rm ./src/.#*
rm ./src/*~
