#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import gtk

class FormGui(gtk.EventBox):
    def __init__(self):
        gtk.EventBox.__init__(self)
        self.set_visible_window(False)
        self.init_titlebar_image()
        self.init_value()
        
        self.widget_fixed = gtk.Fixed()
        self.widget_fixed_event = gtk.EventBox()
        self.widget_fixed_event.add(self.widget_fixed)
        # scrolled window.
        self.fixed_scroll_ali = gtk.Alignment()
        self.fixed_scroll_ali.set(1, 1, 1,1 )
        self.fixed_titlbar_height = 24
        self.fixed_scroll_ali.set_padding(self.fixed_titlbar_height, 2, 2, 2)        
        self.fixed_scroll = gtk.ScrolledWindow()
        self.fixed_scroll_ali.add(self.fixed_scroll)
        self.fixed_scroll.set_policy(
            gtk.POLICY_NEVER,            
            gtk.POLICY_NEVER
            # gtk.POLICY_ALWAYS,
            # gtk.POLICY_ALWAYS            
            )
        self.fixed_scroll.add_with_viewport(self.widget_fixed_event)
        self.widget_fixed.add_events(gtk.gdk.ALL_EVENTS_MASK)
        self.add_events(gtk.gdk.ALL_EVENTS_MASK)
        
        # Init FormGui events.
        self.widget_fixed_event.connect("button-press-event",   self.widget_fixed_press_event)
        self.widget_fixed_event.connect("button-release-event", self.widget_fixed_release_event)
        self.widget_fixed_event.connect("motion-notify-event",  self.widget_fixed_motion_notify_event)
        self.widget_fixed_event.connect("expose-event",         self.widget_fixed_expose_event)
        # 
        self.connect("expose-event", self.draw_window_border_expose)
        self.connect("motion-notify-event", self.motion_notify_event)
        self.add(self.fixed_scroll_ali)
        
    def motion_notify_event(self, widget, event):    
        # self.set_size_request(self.allocation.width, self.allocation.height + 10)
        print "************fdjslfdjl"
        
    def init_titlebar_image(self):
        self.close_pixbuf_path =  gtk.gdk.pixbuf_new_from_file("../image/titlebar/window_close_hover.png")
        self.min_pixbuf_path   =  gtk.gdk.pixbuf_new_from_file("../image/titlebar/window_min_hover.png")
        self.max_pixbuf_path   =  gtk.gdk.pixbuf_new_from_file("../image/titlebar/window_max_hover.png")
        self.titlebar_image_list = [            
            (self.close_pixbuf_path, True),
            (self.max_pixbuf_path, True),
            (self.min_pixbuf_path, True)]
        
    def init_value(self):    
        self.__type = None
        self.__press_offset_x = 0.0
        self.__press_offset_y = 0.0
        self.__release_offset_x = 0.0
        self.__release_offset_y = 0.0
        self.__clear_widget_bool = True
        ################################
        self.__press_draw_bool = False
        self.__draw_start_x = 0
        self.__draw_start_y = 0
        self.__draw_end_x = 0
        self.__draw_end_y = 0
        
    # 左键单击下去生成相应的控件.    
    def widget_fixed_press_event(self, widget, event):
        self.widget_press_event_function(event.x, event.y)
                
    def widget_fixed_release_event(self, widget, event):
        self.widget_release_event_function(event.x, event.y)        
        
    def widget_fixed_motion_notify_event(self, widget, event):    
        if self.__press_draw_bool:
            print "widget_fixed_motion_notify_event:"
            self.__draw_end_x = int(event.x)
            self.__draw_end_y = int(event.y)
            self.queue_draw()
        
    def widget_fixed_expose_event(self, widget, event):
        cr = widget.window.cairo_create()
        # rect = widget.allocation
        # 画界面的背景[改变背景色颜色].
        # self.draw_widget_background(cr, rect)
        # 画拖拉控件显示的黑色方框.
        self.draw_widget_rectangel(cr)
        # 显示界面上的子控件.
        if "get_child" in dir(widget) and widget.get_child() != None:
            widget.propagate_expose(widget.get_child(), event)
        return True
    
    def draw_widget_background(self, cr, rect):        
        cr.set_source_rgb()
        cr.rectangle(rect.x, rect.y, rect.width, rect.height)
        cr.fill()
            
    def draw_widget_rectangel(self, cr):
        if self.__press_draw_bool:
            cr.set_source_rgb(0, 0, 0)
            draw_width = self.__draw_end_x - self.__draw_start_x
            draw_height = self.__draw_end_y - self.__draw_start_y
            cr.rectangle(self.widget_fixed.allocation.x + self.__draw_start_x,
                         self.widget_fixed.allocation.y + self.__draw_start_y,
                         draw_width,
                         draw_height)            
            cr.stroke()
        
    def draw_window_border_expose(self, widget, event):
        cr = widget.window.cairo_create()
        rect = widget.allocation
        # draw titlbar background.
        self.draw_titlebar_background(cr, rect)
        # draw titlebar close, max, min image.
        self.draw_titlebar_close_max_min(cr, rect)
        # 
        cr.set_source_rgb(0, 0, 1)
        cr.set_line_width(2.5)
        cr.rectangle(rect.x, rect.y, rect.width, rect.height)
        cr.stroke()
        # 显示界面上的子控件.
        if "get_child" in dir(widget) and widget.get_child() != None:
            widget.propagate_expose(widget.get_child(), event)
        return True
            
    def draw_titlebar_background(self, cr, rect):        
        cr.set_source_rgb(0, 0, 1)
        cr.rectangle(rect.x, rect.y, rect.width, self.fixed_titlbar_height)
        cr.fill()
        
    def draw_titlebar_close_max_min(self, cr, rect):
        image_width = 0
        padding_y = 0
        for image, show_bool in self.titlebar_image_list:
            if show_bool:
                image_width += image.get_width()
                self.draw_pixbuf(cr, image, rect.x + rect.width - image_width, rect.y + padding_y)
        
    def draw_pixbuf(self, cr, pixbuf, x, y):        
        scale_pixbf = pixbuf.scale_simple(20, 20, gtk.gdk.INTERP_BILINEAR) 
        cr.set_source_pixbuf(scale_pixbf, x, y)        
        cr.paint_with_alpha(1)    
        
        
    def widget_press_event_function(self, press_x, press_y):    
        if self.type_bool():                        
            self.__press_draw_bool = True
            self.__draw_start_x = int(press_x)
            self.__draw_start_y = int(press_y)            
            # 记录press下的location(x,y)
            self.save_location(press_x, press_y)
    
    def widget_release_event_function(self, release_x, release_y):
        if self.type_bool():
            self.__press_draw_bool = False
            self.queue_draw()
            self.__release_offset_x = release_x
            self.__release_offset_y = release_y
            # 转换坐标.
            self.__press_offset_x, self.__press_offset_y, self.__release_offset_x, self.__release_offset_y = self.location_to_min(
                self.__press_offset_x,
                self.__press_offset_y,
                self.__release_offset_x,
                self.__release_offset_y)
            widget_width =  int(abs(self.__release_offset_x - self.__press_offset_x))
            widget_hegiht = int(abs(self.__release_offset_y - self.__press_offset_y))
            # 往界面上添加控件.
            self.widget_fixed_add_child_widget(
                self.__press_offset_x, 
                self.__press_offset_y,
                widget_width,
                widget_hegiht)
            
    def widget_fixed_add_child_widget(self, x, y, w, h):        
        temp_widget = self.type_to_widget_return()
        temp_widget.set_size_request(w, h)
        # .
        self.widget_fixed.put(
            temp_widget, 
            int(x),
            int(y)
            )
        # 显示fixed上的控件.
        self.widget_fixed.show_all()
        if self.__clear_widget_bool:
            self.clear_type()
            
    def type_to_widget_return(self):   
        if self.__type == "Button":
            widget = gtk.Button()
        elif self.__type == "TextEntry":
            widget = gtk.Entry()
        elif self.__type == "TextView":    
            widget = gtk.TextView()
        elif self.__type == "ProgressBar":
            widget = gtk.ProgressBar()
            
        widget.add_events(gtk.gdk.ALL_EVENTS_MASK)
        widget.connect("button-press-event",   self.widget_press_event)
        widget.connect("button-release-event", self.widget_release_event)
        # widget.connect("motion_notify_event",  self.widget_motion_notify_event)
        # widget.connect("expose-event")
        return widget
    
    def widget_press_event(self, widget, event):
        widget_press_x = widget.allocation.x + event.x
        widget_press_y = widget.allocation.y + event.y
        self.widget_press_event_function(widget_press_x, widget_press_y)
        
    def widget_release_event(self, widget, event):
        widget_release_x = widget.allocation.x + event.x
        widget_release_y = widget.allocation.y + event.y
        self.widget_release_event_function(widget_release_x, widget_release_y)
        
    def set_type(self, type):
        self.__type = type
        
    def clear_type(self):    
        self.__type = None
        
    def save_location(self, x , y):    
        self.__press_offset_x = x
        self.__press_offset_y = y
        
    def type_bool(self):
        if self.__type:
            return True
        else:
            return False
        
    def set_clear_widget_type_bool(self, widget_bool):
        self.__clear_widget_bool = widget_bool
        
    # 转换控件坐标.
    def location_to_min(self, start_x, start_y, end_x, end_y):
        temp_x = start_x
        temp_y = start_y
        
        if start_x > end_x and start_y > end_y:
            start_x = end_x
            start_y = end_y
            end_x = temp_x
            end_y = temp_y
        elif start_x < end_x and start_y > end_y:
            start_y = end_y
            end_y = temp_y
        elif start_x > end_x and start_y < end_y:
            start_x = end_x
            end_x = temp_x
        
        return start_x, start_y, end_x, end_y
        
class WidgetTree(object):
    '''控件树,保存父控件和子控件之间的关系'''
    def __init__(self):
        self.widget = None
        self.left_widget = None
        self.right_widget = None
    
if __name__ == "__main__":        
    def btn_clicked(widget, type_text):
        print "type", type_text
        form_gui.set_type(type_text)
        form_gui2.set_type(type_text)
        
    win = gtk.Window(gtk.WINDOW_TOPLEVEL)
    fixed = gtk.Fixed()
    hbox = gtk.HBox()
    vbox = gtk.VBox()
    pre_hbox = gtk.HBox()
    
    form_gui = FormGui()    
    form_gui2 = FormGui()
    btn1 = gtk.Button("按钮")
    btn2 = gtk.Button("文本")
    btn3 = gtk.Button("高级文本")
    btn4 = gtk.Button("进度条")
    btn1.connect("clicked", btn_clicked, "Button")
    btn2.connect("clicked", btn_clicked, "TextEntry")
    btn3.connect("clicked", btn_clicked, "TextView")
    btn4.connect("clicked", btn_clicked, "ProgressBar")
    
    vbox.pack_start(btn1)
    vbox.pack_start(btn2)
    vbox.pack_start(btn3)
    vbox.pack_start(btn4)
    
    form_gui.set_size_request(300, 300)
    form_gui2.set_size_request(300, 300)
    
    fixed.put(form_gui, 20, 20)
    fixed.put(form_gui2, 340, 20)
    hbox.pack_start(vbox, False, False)
    hbox.pack_start(fixed)
    win.add(hbox)
    win.show_all()
    gtk.main()
    
        
